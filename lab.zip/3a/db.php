<?php

//For localhost
mysql_connect("localhost", "root", "") or die("Cannot connect");
mysql_select_db("cse72") or die("Cannot select DB");


//For Live Server
//mysql_connect("localhost", "hasan_admin", "lIDH?(-~R~Ah") or die("Cannot connect");
//mysql_select_db("hasan_cse72") or die("Cannot select DB");


?>