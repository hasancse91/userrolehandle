<?php 
include "db.php";

	$name = $_POST['userName'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$gender = $_POST['gender'];
	$experiences = $_POST['skill'];
	$message = $_POST['message'];



	mysql_query("INSERT INTO `user_info` (user_name, email, password, gender, message) VALUES ('$name', '$email', '$password', '$gender', '$message')");

	$res = mysql_query("SELECT * FROM user_info WHERE email = '$email'");
	$rowId = mysql_fetch_array($res);
	$user_id = $rowId['user_id'];

	foreach ($experiences as $skill) {
		mysql_query("INSERT INTO `user_experience` (user_id, experience) VALUES('$user_id', '$skill')");
	}


	$result = mysql_query("SELECT * FROM `user_info` WHERE user_id = '$user_id'");
	$result_experience = mysql_query("SELECT experience FROM `user_experience` WHERE user_id = '$user_id'");

	$count = mysql_num_rows($result);
	If($count > 0){
		$row = mysql_fetch_array($result);
		echo $row['user_name']."<br>".$row['email']."<br>".$row['gender']."<br>".$row['message']."<br><br>";	
	}

	echo "<b>Experiences:</b><br>";

	while($row = mysql_fetch_array($result_experience)){
		echo $row['experience']."<br>";
	}


 ?>

