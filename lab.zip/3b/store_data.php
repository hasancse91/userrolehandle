<?php
include "db.php";

$name = $_POST['user_name'];
$email = $_POST['email'];
$bengali = $_POST['bengali'];
$english = $_POST['english'];
$math = $_POST['math'];

mysql_query("INSERT INTO `user_info` (user_name, email, bengali, english, math) VALUES ('$name', '$email', '$bengali', 'english', 'math')");

echo "<b>Marks:</b><br>";
echo "Bengali: ".$bengali."<br>"."English: ".$english."<br>"."Math: ".$math."<br>";

$avg = ($bengali + $english + $math)/3;

if($avg >= 80)
	echo "GPA: A+";
elseif ($avg>=60 && $avg<80)
	echo "GPA: A";
elseif ($avg>=50 && $avg<60)
	echo "GPA: B";
elseif ($avg>=50 && $avg<60)
	echo "GPA: C";
else
	echo "GPA: F";

?>